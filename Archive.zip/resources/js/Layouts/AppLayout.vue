<script setup lang="ts">
import { Link } from '@inertiajs/vue3'
</script>

<template>
    <div class="min-h-screen bg-white text-gray-900 flex flex-col">
        <header class="border-b">
            <nav class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
                <Link href="/" class="font-bold text-lg">Hayk.dev</Link>
                <div class="flex items-center gap-6 text-sm">
                    <Link href="/">Home</Link>
                    <a href="/#about">About</a>
                    <a href="/#projects">Portfolio</a>
                    <Link href="/order">Order</Link>
                    <a href="/#contact">Contact</a>
                    <a href="/#free-consultation" class="px-3 py-1 rounded-full border hover:bg-black hover:text-white">
                        Free consult
                    </a>
                </div>
            </nav>
        </header>

        <main class="flex-1">
            <slot />
        </main>

        <footer class="border-t">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-sm text-gray-500">
                © {{ new Date().getFullYear() }} Hayk.dev — Laravel & Vue Engineer
            </div>
        </footer>
    </div>
</template>
