<script setup lang="ts">
import { Head } from '@inertiajs/vue3'
import AppLayout from '@/Layouts/AppLayout.vue'

const works = [
  { title: 'Project A', summary: 'Laravel + Vue SPA', year: 2024 },
  { title: 'Project B', summary: 'Nuxt SSR platform', year: 2023 },
  { title: 'Project C', summary: 'Realtime dashboards', year: 2022 },
]
</script>

<template>
  <Head title="Portfolio" />
  <AppLayout>
    <section class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <h1 class="text-3xl font-bold">Portfolio</h1>
      <p class="mt-4 text-gray-600">A selection of projects I’ve delivered.</p>
      <div class="mt-8 grid gap-6 sm:grid-cols-2">
        <article v-for="w in works" :key="w.title" class="rounded-xl border p-5">
          <h3 class="font-semibold">{{ w.title }}</h3>
          <p class="text-sm text-gray-600">{{ w.summary }}</p>
          <p class="mt-1 text-xs text-gray-400">{{ w.year }}</p>
        </article>
      </div>
    </section>
  </AppLayout>
</template>
