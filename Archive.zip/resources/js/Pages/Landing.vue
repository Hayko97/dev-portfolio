<script setup lang="ts">
import { Head, Link } from '@inertiajs/vue3'
import AppLayout from '@/Layouts/AppLayout.vue'

const socials = [
  { name: 'GitHub', href: 'https://github.com/', icon: '🐙' },
  { name: 'LinkedIn', href: 'https://linkedin.com/', icon: '🔗' },
  { name: 'X', href: 'https://x.com/', icon: '𝕏' },
]

const skills: { name: string; level: number }[] = [
  { name: 'TypeScript', level: 90 },
  { name: 'Vue 3', level: 92 },
  { name: 'Laravel', level: 88 },
  { name: 'Inertia.js', level: 85 },
  { name: 'TailwindCSS', level: 90 },
]

const projects = [
  {
    title: 'Project A',
    desc: 'Modern SPA with Laravel + Inertia + Vue.',
    tech: ['Laravel', 'Vue', 'TS'],
    link: '#',
  },
  {
    title: 'Project B',
    desc: 'Full‑stack app with REST API and SSR.',
    tech: ['Node', 'Nuxt', 'Postgres'],
    link: '#',
  },
  {
    title: 'Project C',
    desc: 'Real‑time dashboard with websockets.',
    tech: ['Laravel Echo', 'Vue', 'Tailwind'],
    link: '#',
  },
]
</script>

<template>
  <Head title="Home" />
  <AppLayout>
    <!-- Hero -->
    <section class="relative isolate overflow-hidden">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28 grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <p class="text-sm uppercase tracking-widest text-gray-500">Laravel • Vue • Inertia</p>
          <h1 class="mt-3 text-4xl sm:text-5xl font-extrabold tracking-tight text-gray-900">Hi, I’m Hayk — I build delightful web apps.</h1>
          <p class="mt-6 text-lg leading-8 text-gray-600">Senior full‑stack engineer specializing in Laravel + Vue 3 with TypeScript. I ship fast, accessible, and maintainable products.</p>
          <div class="mt-8 flex items-center gap-3">
            <Link href="/order" class="inline-flex items-center justify-center rounded-md bg-black px-5 py-2.5 text-white text-sm font-medium shadow hover:bg-gray-900">Start a project</Link>
            <a href="#projects" class="inline-flex items-center justify-center rounded-md border px-5 py-2.5 text-sm font-medium hover:bg-gray-50">View work</a>
          </div>
          <div class="mt-6 flex items-center gap-4 text-sm text-gray-500">
            <span>Find me on</span>
            <template v-for="s in socials" :key="s.name">
              <a :href="s.href" target="_blank" rel="noreferrer" class="hover:text-gray-900">
                <span class="mr-1">{{ s.icon }}</span>{{ s.name }}
              </a>
            </template>
          </div>
        </div>
        <div class="relative">
          <div class="aspect-square rounded-2xl bg-gradient-to-br from-gray-100 to-gray-200 border" />
        </div>
      </div>
    </section>

    <!-- About / Skills -->
    <section id="about" class="border-t">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div class="grid lg:grid-cols-2 gap-12">
          <div>
            <h2 class="text-2xl font-bold">About</h2>
            <p class="mt-4 text-gray-600">I craft robust backends with Laravel and seamless frontends with Vue 3 and TypeScript. I care about DX, clean architecture, and performance.</p>
            <div class="mt-6">
              <a href="#about" class="text-sm font-medium underline hover:no-underline">More about me →</a>
            </div>
          </div>
          <div>
            <h2 class="text-2xl font-bold">Skills</h2>
            <ul class="mt-4 space-y-4">
              <li v-for="s in skills" :key="s.name">
                <div class="flex justify-between text-sm">
                  <span class="font-medium">{{ s.name }}</span>
                  <span class="text-gray-500">{{ s.level }}%</span>
                </div>
                <div class="mt-1 h-2 bg-gray-100 rounded">
                  <div class="h-2 rounded bg-gray-900" :style="{ width: s.level + '%' }" />
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>

    <!-- Projects -->
    <section id="projects" class="border-t">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div class="flex items-end justify-between">
          <h2 class="text-2xl font-bold">Selected projects</h2>
          <a href="#projects" class="text-sm font-medium underline hover:no-underline">All projects →</a>
        </div>
        <div class="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <article v-for="p in projects" :key="p.title" class="rounded-xl border hover:shadow-sm transition">
            <div class="p-5">
              <h3 class="font-semibold">{{ p.title }}</h3>
              <p class="mt-2 text-sm text-gray-600">{{ p.desc }}</p>
              <div class="mt-3 flex flex-wrap gap-2">
                <span v-for="t in p.tech" :key="t" class="text-xs rounded-full bg-gray-100 px-2 py-0.5">{{ t }}</span>
              </div>
              <a :href="p.link" class="mt-4 inline-flex text-sm font-medium underline hover:no-underline">Open →</a>
            </div>
          </article>
        </div>
      </div>
    </section>

    <!-- Free Consultation Section -->
    <section id="free-consultation" class="border-t">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div class="rounded-2xl border p-8 sm:p-10 lg:p-12 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div>
            <h2 class="text-2xl font-bold">Free consultation</h2>
            <p class="mt-2 text-gray-600">Book a quick call to discuss your idea, assess feasibility, and outline next steps.</p>
          </div>
          <div class="flex gap-3">
            <a href="#contact" class="inline-flex items-center justify-center rounded-md bg-black px-5 py-2.5 text-white text-sm font-medium shadow hover:bg-gray-900">Book now</a>
          </div>
        </div>
      </div>
    </section>

    <!-- Contact CTA -->
    <section id="contact" class="border-t">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div class="rounded-2xl border p-8 sm:p-10 lg:p-12 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div>
            <h2 class="text-2xl font-bold">Have an idea? Let’s build it.</h2>
            <p class="mt-2 text-gray-600">I’m available for freelance/contract work. Get a free consultation and estimate.</p>
          </div>
          <div class="flex gap-3">
            <a href="#free-consultation" class="inline-flex items-center justify-center rounded-md bg-black px-5 py-2.5 text-white text-sm font-medium shadow hover:bg-gray-900">Free consultation</a>
            <a href="#contact" class="inline-flex items-center justify-center rounded-md border px-5 py-2.5 text-sm font-medium hover:bg-gray-50">Contact</a>
          </div>
        </div>
      </div>
    </section>
  </AppLayout>
</template>
